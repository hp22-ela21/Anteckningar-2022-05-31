#ifndef VECTOR_H_
#define VECTOR_H_

/* Inkluderingsdirektiv: */
#include <stdio.h>
#include <stdlib.h>

typedef enum { SORT_DIRECTION_ASCENDING, SORT_DIRECTION_DESCENDING } sort_direction_t;

/***********************************************************************************
* vector_t: Dynamisk vektor f�r lagring av flyttal.
***********************************************************************************/
typedef struct
{
   double* data; /* Pekare till dynamiskt f�lt inneh�llande flyttal. */
   size_t size; /* Antalet element i f�ltet. */
} vector_t;

/* Funktionsdeklarationer: */
void vector_new(vector_t* self);
void vector_delete(vector_t* self);
vector_t* vector_ptr_new(void);
void vector_ptr_delete(vector_t** self);
void vector_resize(vector_t* self, const size_t new_size);
void vector_push(vector_t* self, const double new_element);
void vector_pop(vector_t* self);
void (*vector_clear)(vector_t* self);
void vector_print(const vector_t* self, FILE* stream);
void vector_sort(vector_t* self, const sort_direction_t sort_direction);

#endif /* VECTOR_H_ */