/* Inkluderingsdirektiv: */
#include "vector.h"

/***********************************************************************************
* vector_new: Konstruktor f�r objekt av strukten vector_t. Adressen till det
*             oinitierade objektet passeras s� att initiering sker utan att
*             det relativt stora objektet beh�ver returneras via stacken.
***********************************************************************************/
void vector_new(vector_t* self)
{
   self->data = 0;
   self->size = 0;
   return;
}

/***********************************************************************************
* vector_delete: Destruktor f�r objekt av strukten vector_t. Allokerat minne f�r
*                det dynamiska f�ltet frig�rs, men sj�lva objektet raderas inte 
*                g�r att anv�nda igen.
***********************************************************************************/
void vector_delete(vector_t* self)
{
   free(self->data);
   self->data = 0;
   self->size = 0;
   return;
}

/***********************************************************************************
* vector_ptr_new: Konstruktor f�r dynamiskt allokerade vektorer, d�r en pekare 
*                 till vektorn i fr�ga returneras. Minne allokeras f�r den
*                 nya vektorn, f�ljt av att denna initieras och returneras.
***********************************************************************************/
vector_t* vector_ptr_new(void)
{
   vector_t* self = (vector_t*)malloc(sizeof(vector_t));
   if (!self) return 0;
   vector_new(self);
   return self;
}

/***********************************************************************************
* vector_ptr_delete: Destruktor f�r dynamiskt allokerade vektorer. Allokerat minne 
*                    frig�rs b�de f�r det dynamiska f�ltet samt sj�lva objektet.
*                    En dubbelpekare passeras f�r att kunna s�tta vektorpekaren
*                    till null. Annars forts�tter denna peka d�r vektorn tidigare
*                    l�g i minnet, vilket kan orsaka problem.
***********************************************************************************/
void vector_ptr_delete(vector_t** self)
{
   vector_delete(*self);
   free(*self);
   *self = 0;
   return;
}

/***********************************************************************************
* vector_resize: �ndrar storlek p� det dynamiskt allokerade f�ltet. Ifall angiven
*                storlek �r noll s� t�ms vektorn, annars sker omallokering.
***********************************************************************************/
void vector_resize(vector_t* self, const size_t new_size)
{
   if (!new_size)
   {
      vector_delete(self);
   }
   else
   {
      double* copy = (double*)realloc(self->data, sizeof(double) * new_size);
      if (!copy) return;
      self->data = copy;
      self->size = new_size;
   }
   return;
}

/***********************************************************************************
* vector_push: L�gger till ett nytt element l�ngst bak i det dynamiska f�ltet.
*              F�r att f� plats med det nya elementet sker omallokering.
***********************************************************************************/
void vector_push(vector_t* self, const double new_element)
{
   double* copy = (double*)realloc(self->data, sizeof(double) * (self->size + 1));
   if (!copy) return;
   copy[self->size++] = new_element;
   self->data = copy;
   return;
}

/***********************************************************************************
* vector_pop: Tar bort ett element l�ngst bak i det dynamiska f�ltet. Om vektorn
*             kommer vara tom efter borttagandet sker en total nollst�llning.
*             Annars sker omallokering av det dynamiska f�ltet.
***********************************************************************************/
void vector_pop(vector_t* self)
{
   if (self->size <= 1)
   {
      vector_delete(self);
   }
   else
   {
      double* copy = (double*)realloc(self->data, sizeof(double) * (self->size - 1));
      if (!copy) return;
      self->data = copy;
      self->size--;
   }
   return;
}

/***********************************************************************************
* vector_clear: Funktionspekare f�r att t�mma ett dynamiskt f�lt. Eftersom detta
*               redan genomf�rs av destruktorn vector_delete, d�r vektorn i sig
*               inte kan raderas ifall denna �r statiska allokerad, s� implementeras 
*               h�r endast en funktionspekare, som fr�mst anv�nds f�r att g�ra
*               det enklare f�r anv�ndaren att hitta en funktion som medf�r att
*               ett dynamiskt f�lt t�ms utan att radera vektorn.
***********************************************************************************/
void (*vector_clear)(vector_t* self) = vector_delete;

/***********************************************************************************
* vector_print: Skriver ut inneh�llet lagrat i ett dynamiskt f�lt via en valbar
*               I/O-str�m. Om ingen str�m har angivits anv�nds standardutenheten
*               stdout f�r utskrift i konsolen.
***********************************************************************************/
void vector_print(const vector_t* self, FILE* stream)
{
   if (!self->size) return;
   if (!stream) stream = stdout;
   fprintf(stream, "-------------------------------------------------------------------\n");
   for (register double* i = self->data; i < self->data + self->size; ++i)
      fprintf(stream, "%g\n", *i);
   fprintf(stream, "-------------------------------------------------------------------\n\n");
   return;
}

/***********************************************************************************
* vector_sort: Sorterar inneh�llet i ett dynamiskt f�lt i valbar ordning.
***********************************************************************************/
void vector_sort(vector_t* self, const sort_direction_t sort_direction)
{
   for (register volatile double* i = self->data; i < self->data + self->size - 1; ++i)
   {
      for (register volatile double* j = i + 1; j < self->data + self->size; ++j)
      {
         if ((sort_direction == SORT_DIRECTION_ASCENDING && *i > *j) ||
             (sort_direction == SORT_DIRECTION_DESCENDING && *i < *j))
         {
            const double temp = *i;
            *i = *j;
            *j = temp;
         }
      }
   }
   return;
}