/* Inkluderingsdirektiv: */
#include "vector.h"

/***********************************************************************************
* file_read: L�ser inneh�llet fr�n en fil rad f�r rad och skriver ut i konsolen.
***********************************************************************************/
static void file_read(const char* filepath)
{
   FILE* fstream = fopen(filepath, "r");
   if (!fstream)
   {
      fprintf(stderr, "Could not open file at path %s!\n\n", filepath);
   }
   else
   {
      char s[100];
      s[0] = '\0';
      while (fgets(s, sizeof(s), fstream))
         fprintf(stdout, "%s", s);
      fclose(fstream);
   }
   return;
}

/***********************************************************************************
* main: Deklarerar tv� vektorer, en statiskt allokerad vektor d�pt v1 samt en 
*       dynamiskt allokerad vektor d�pt v2. Storleken p� v1 s�tts top, f�ljt av 
*       att denna vektor tilldelas tio flyttal p� allokerade adresser. Direkt
*       efter varje tilldelning s� l�ggs motsvarande v�rde multiplicerat med tv�
*       l�ngst bak i v2 via en push-operation. Inneh�llet i v2 sorteras sedan i
*       fallande ordning. Vektorernas inneh�ll skrivs d�refter till en textfil 
*       d�pt data.txt. Innan programmet avslutas s� l�ses inneh�llet fr�n denna 
*       fil och skrivs ut i konsolen.
***********************************************************************************/
int main(void)
{
   vector_t v1, *v2;
   FILE* fstream = fopen("data.txt", "a");

   vector_new(&v1);
   v2 = vector_ptr_new();
   vector_resize(&v1, 10);

   for (register size_t i = 0; i < v1.size; ++i)
   {
      v1.data[i] = (double)(i + 0.5);
      vector_push(v2, v1.data[i] * 2);
   }

   vector_sort(v2, SORT_DIRECTION_DESCENDING);
   vector_print(&v1, fstream);
   vector_print(v2, fstream);
   fclose(fstream);
   file_read("data.txt");

   vector_delete(&v1);
   vector_ptr_delete(&v2);
   return 0;
}